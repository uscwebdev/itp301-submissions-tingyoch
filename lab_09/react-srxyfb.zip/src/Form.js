import React from 'react';
import { useState } from 'react';

export default function Form() {
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [email, setEmail] = useState('');
  const [number, setNumber] = useState('');
  const [comment, setComment] = useState('');
  const [terms, setTerms] = useState(false);

  const [count, setCount] = useState('0');

  // const [nameError, setNameError] = useState();
  // const [passwordError, setPasswordError] = useState();
  // const [confirmPasswordError, setConfirmPasswordError] = useState();
  // const [contactError, setContactError] = useState();
  // const [commentError, setCommentError] = useState();
  // const [tandcError, setTandCError] = useState();

  function handleSubmit(e) {
    var foundError = false;

    //NAME validation rules
    if (name.length == 0) {
      //name cannot be empty
      foundError = true;
      alert('Name cannot be empty.');
    } else if (name.indexOf(' ') == -1) {
      //Must have space between words.
      foundError = true;
      alert('You must provide a full name.');
    }

    //PASSWORD validation rules
    if (password.length == 0) {
      //password cannot be empty
      foundError = true;
      alert('Password cannot be empty.');
    } else if (password.length < 5) {
      //password must contain at least 5 characters
      foundError = true;
      alert('Password must contain at least 5 characters.');
    } else if (password == password.toLowerCase()) {
      //password must contain both upper and lower case letters
      foundError = true;
      alert('Password must contain uppercase and lowercase characters.');
    } else if (password == password.toUpperCase()) {
      //password must contain both upper and lwoer case letters
      foundError = true;
      alert('Password must contain uppercase and lowercase characters.');
    }

    //CONFIRM password validation
    if (password != confirmPassword) {
      foundError = true;
      alert('Passwords do not match.');
    }

    //EMAIL & PHONE validation rules
    if (email.length === '' || number.length === '') {
      //must provide an email OR phone
      foundError = true;
      alert('You must provide either email or phone.');
    }

    //COMMENTS validation rules
    if (comment.length > 100) {
      //comment cannot exceed 100 characters
      foundError = true;
      alert('Comments cannot exceed 100 characters.');
    }

    //T&C validation rules
    if (terms == false) {
      //T&C must be checked
      foundError = true;
      alert('You must accept Terms & Conditions.');
    }

    if (foundError == false) {
      alert('Registration successful.');
    }
  }

  return (
    <div className="container my-3" onSubmit={handleSubmit}>
      <div className="row">
        <div className="col-12">
          <form>
            <div className="my-3 row">
              <label htmlFor="full-name" className="col-sm-2 col-form-label">
                Full Name: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Tommy Trojan"
                  id="full-name"
                  onChange={(e) => {
                    setName(e.currentTarget.value);
                  }}
                  value={name}
                />
              </div>
            </div>

            <div className="my-3 row">
              <label htmlFor="password" className="col-sm-2 col-form-label">
                Password: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="password"
                  className="form-control"
                  id="password"
                  onChange={(e) => {
                    setPassword(e.currentTarget.value);
                  }}
                  value={password}
                />
              </div>
            </div>

            <div className="my-3 row">
              <label
                htmlFor="password-confirm"
                className="col-sm-2 col-form-label"
              >
                Confirm Password: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="password"
                  className="form-control"
                  id="password-confirm"
                  onChange={(e) => {
                    setConfirmPassword(e.currentTarget.value);
                  }}
                  value={confirmPassword}
                />
              </div>
            </div>

            <div className="my-3 row">
              <label className="col-sm-2 col-form-label">
                Provide One: <span className="text-danger">*</span>
              </label>
              <div className="col-10">
                <div className="row">
                  <label htmlFor="email" className="col-sm-2 col-form-label">
                    Email:
                  </label>
                  <div className="col-sm-10">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="ttrojan@usc.edu"
                      id="email"
                      onChange={(e) => {
                        setEmail(e.currentTarget.value);
                      }}
                      value={email}
                    />
                  </div>

                  <label
                    htmlFor="phone"
                    className="mt-sm-2 col-sm-2 col-form-label"
                  >
                    Phone:
                  </label>
                  <div className="mt-sm-2 col-sm-10">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="(123) 456-7890"
                      id="phone"
                      onChange={(e) => {
                        setNumber(e.currentTarget.value);
                      }}
                      value={number}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="my-3 row">
              <label htmlFor="comment" className="col-sm-2 col-form-label">
                Comments:
              </label>
              <div className="col-sm-10">
                <textarea
                  className="form-control"
                  id="comment"
                  onChange={(e) => {
                    setComment(e.currentTarget.value);
                    setCount(e.currentTarget.value.length);
                  }}
                  value={comment}
                ></textarea>

                <small id="comment-count" className="form-text text-right">
                  {count} / 100
                </small>
              </div>
            </div>

            <div className="my-3 row">
              <label className="col-sm-2 col-form-label"></label>
              <div className="col-sm-10">
                <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    id="terms"
                    onChange={(e) => {
                      setTerms(e.currentTarget.value);
                    }}
                    value={terms}
                  />
                  <label className="form-check-label" htmlFor="terms">
                    I accept Terms & Conditions.
                    <span className="text-danger">*</span>
                  </label>
                </div>
              </div>
            </div>

            <div className="my-3 row">
              <div className="col-sm-10">
                <button type="submit" className="btn btn-primary">
                  Register
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
