import React from 'react';
import About from './About.js';
import Creative from './Creative.js';
import Analytic from './Analytic.js';
import ContactMe from './ContactMe.js';

export default function NavBar() {
  return (
    <div className="nav-bar-full">
      <ul>
        <li>
          <a className="nav-black" className="nav-left" href="About.js">
            TINGYO CHANG
          </a>
        </li>
        <li>
          <div className="contact-btn">
            <a className="nav-right" href="ContactMe.js">
              Contact Me
            </a>
          </div>
        </li>
        <li>
          <a className="nav-black" className="nav-right" href="Analytic.js">
            Anaytic
          </a>
        </li>
        <li>
          <a className="nav-black" className="nav-right" href="Creative.js">
            Creative
          </a>
        </li>
        <li>
          <a className="nav-black" className="nav-right" href="About.js">
            About
          </a>
        </li>
      </ul>
    </div>
  );
}
