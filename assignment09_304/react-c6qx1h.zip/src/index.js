import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import NavBar from './NavBar.js';
import About from './About.js';
import Creative from './Creative.js';
import Analytic from './Analytic.js';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <NavBar />
    <About />
    <Creative />
    <Analytic />
  </React.StrictMode>
);
