import React from 'react';

export default function About() {
  return (
    <div className="content-box">
      <div id="about-pic">
        <img
          id="about-pic"
          src="https://d2gr0dan0snfpj.cloudfront.net/attachments/5y01zA1r1vpgzn88Y0jUP.jpg"
          alt="Profile Photo"
        />
      </div>
      <div id="about-txt">
        <h1 className="center-txt">Tingyo Chang</h1>
        <p>
          Narrative Studies; Law, History, and Culture. These are my majors,
          here is my general vibe. Here are some words on what I am looking for
          and I am trying to finish this site.
        </p>
      </div>
    </div>
  );
}
