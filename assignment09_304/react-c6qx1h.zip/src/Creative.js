import React from 'react';

export default function Creative() {
  return (
    <div className="content-box">
      <div className="sub-section-container">
        <img
          className="vertical-pic"
          src="https://i.etsystatic.com/18489029/r/il/aa1d37/3505960887/il_570xN.3505960887_ev90.jpg"
          alt="NYC Skyline"
        />
        <a href="https://docs.google.com/document/d/1JxdiYpwl9dgFbuRnVtV7N5krsuGQzcr7xvzj0ElQrLs/edit?usp=sharing">
          <h2>A Minute in New York</h2>
        </a>
      </div>
      <div className="sub-section-container">
        <img
          className="vertical-pic"
          src="https://us.123rf.com/450wm/grynold/grynold1404/grynold140400178/27685324-silhouette-of-a-mother-and-son-on-the-walk.jpg?ver=6"
          alt="Mother and Daughter Silhoutte"
        />
        <a href="https://docs.google.com/document/d/1rIh87NG5HTyb2YuindGJAnuVx7QEXlCowc9eSknLD-I/edit?usp=sharing">
          <h2>My Mother and Me</h2>
        </a>
      </div>
      <div className="sub-section-container">
        <img
          className="vertical-pic"
          src="https://i.etsystatic.com/9344733/r/il/f3c678/4893516660/il_794xN.4893516660_s7yt.jpg"
          alt="Cup of Matcha"
        />
        <a href="https://docs.google.com/document/d/1rD-S2fr5nWVzR0xd-FqipDcvx6Osa9vB_RP_QAeUOS0/edit?usp=sharing">
          <h2>Love Languages</h2>
        </a>
      </div>
    </div>
  );
}
