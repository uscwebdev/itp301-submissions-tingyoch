import React from 'react';

export default function Analytic() {
  return (
    <div className="content-box">
      <div className="sub-section-container">
        <img
          className="vertical-pic"
          src="https://i0.wp.com/hyperallergic-newspack.s3.amazonaws.com/uploads/2023/03/Mulyana_002-1200x1600.jpg?resize=780%2C1040&quality=100&ssl=1"
          alt="Mulyana Artwork"
        />
        <a href="https://docs.google.com/document/d/1aSPg6Fd0Nu5FUJuJhmG6TwWOUutPlnVbsy506QZ6mxU/edit?usp=sharing">
          <h2>Mulyana: Modular Utopia</h2>
        </a>
      </div>
      <div className="sub-section-container">
        <img
          className="vertical-pic"
          src="https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/d4c5eab9-6ca8-43bb-b4c3-755be2d0ffd0/dehlhpf-8557501d-0e0d-490e-baea-02c558bd7456.png/v1/fill/w_1280,h_1751/aggretsuko___retsuko_by_barryductions_dehlhpf-fullview.png?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9MTc1MSIsInBhdGgiOiJcL2ZcL2Q0YzVlYWI5LTZjYTgtNDNiYi1iNGMzLTc1NWJlMmQwZmZkMFwvZGVobGhwZi04NTU3NTAxZC0wZTBkLTQ5MGUtYmFlYS0wMmM1NThiZDc0NTYucG5nIiwid2lkdGgiOiI8PTEyODAifV1dLCJhdWQiOlsidXJuOnNlcnZpY2U6aW1hZ2Uub3BlcmF0aW9ucyJdfQ.34CsWtK96lxrh2B8-TuxWGH9gRd5r1tU0Wzr7P1gbz4"
          alt="Aggretsuko"
        />
        <a href="https://docs.google.com/document/d/1T_pAtGi2z3BLM2gpYnituyEvoIB1uIqkH1Fp8jxpd6I/edit?usp=sharing">
          <h2>Neoliberalism in TV</h2>
        </a>
      </div>
      <div className="sub-section-container">
        <img
          className="vertical-pic"
          src="https://upload.wikimedia.org/wikipedia/en/1/1e/Everything_Everywhere_All_at_Once.jpg"
          alt="Everything Everywhere All at Once"
        />
        <a href="https://docs.google.com/document/d/1r4LlfATqRH9NdoRUeSp2tLSZQZd44qDoEq7Sk4vyNh0/edit?usp=sharing">
          <h2>Multi-Universal, Multi-faceted</h2>
        </a>
      </div>
    </div>
  );
}
