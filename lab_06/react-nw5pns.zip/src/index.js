import React from 'react';
import { createRoot } from 'react-dom/client';
import Comments from './Comment.js';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div id="fixed-heading">
      <div id="header-left">
        <h5>Movie Reviews</h5>
      </div>
      <div id="header-right">
        <h5>Release: 9 December 2016</h5>
      </div>
    </div>
    <div id="heading">
      <h1>La La Land</h1>
    </div>
    <div id="body">
      <h2>Review</h2>
      <p>
        Musicals have always been one of my favorite genres. There’s something
        just doubly magical and entertaining about a love story told through
        music, and La La Land is no exception. In fact, La La Land represents a
        growth and a maturity in the genre of musicals that can sometimes be
        hard to find. Featuring a certain complexity in storytelling and a
        mastery of music composition, La La Land is a moving romance that
        acknowledges how love and success can or cannot coexist in real life,
        how love can be integral to success, even if it does not always appear
        the way we want love to.
      </p>
      <p>
        Following and unsuccessful audition and an unsuccessful night out with
        friends, struggling actress Mia Dolan (portrayed by Emma Roberts) walks
        home. As she walks, she is drawn into a restaurant by the restaurant’s
        jazz piano performer, struggling musician Sebb Wilder (portrayed by Ryan
        Goling). Although she witnesses Wilder get fired for his refusal to
        perform the owner’s desired set list, she is impressed by his artistry.
        Eventually, the two begin to date as they chase their dreams in La La
        Land in parallel, but they break-up when they begin to encounter
        increasing obstacles in their respective careers; Mia decides to give up
        on her dreams and moves back to her hometown of Boulder City, Nevada.
        But, after the break-up, Wilder receives a call meant for Mia from a
        prominent casting director who wants her to audition for a role. Sebb
        drives to Boulder City and convinces Mia to take a last chance on the
        audition.
      </p>
      <p>
        Five years later, Mia is a successful actress and Sebb has opened up the
        jazz club he had always dreamed of. Seated next to her husband, Mia
        locks eyes with Sebb, who is onstage. They lock eyes and the audience
        sees a montage of an alternate universe where Mia and Sebb had stayed
        together. Although indulgent and sweet, the audience understands that
        without the catalyst of their relationship and subsequent break up, they
        may have never reached the success they have found now.
      </p>

      <p>
        Enjoy the trailer
        <a href="https://www.youtube.com/watch?v=0pdqf4P9MB8"> here</a>!
      </p>
      <h2>Screencaps</h2>
      <div id="photo-collection">
        <img
          src="https://s1.r29static.com/bin/entry/0fe/x,80/1703917/image.jpg"
          alt="Mia and Sebb strolling  scene."
          className="vertical"
        />
        <img
          src="https://i.pinimg.com/236x/d1/6f/08/d16f080f78d3ebc25cdcd011e19be2f3.jpg"
          alt="Mia and Sebb fantasy scene."
          className="vertical"
        />
        <img
          src="https://assets.teenvogue.com/photos/581b8edcc1cacbb91ceb1857/16:9/w_1408,h_792,c_limit/Screen%20Shot%202016-11-03%20at%203.17.04%20PM.png"
          alt="Mia and Sebb walking on lot."
          className="horizontal"
        />
        <img
          src="https://www.indiewire.com/wp-content/uploads/2016/12/la-la-land-emma-stone-and-ryan-gosling-december-2016-movie.jpg"
          alt="Mia and Sebb at bar."
          className="horizontal"
        />
      </div>
      <h2>Comments</h2>
      <Comments
        src="https://www.freeiconspng.com/uploads/person-icon-person-icon-clipart-image-from-our-icon-clipart-category--9.png"
        alt="Hesterp profile"
        date="Posted: 09/24/2023"
        username="Hesterp"
        commented="Even after all these years, this is still my favorite movie by far.
            These roles were meant for Ryan Gosling and Emma Stone to play. I
            can't imagine a better cast or director."
      />
      <Comments
        src="https://i.pinimg.com/originals/9d/e2/ca/9de2ca8358fd0d19e37c3742d38aab0e.png"
        alt="HungryHungryHippo profile"
        date="Posted: 07/16/2020"
        username="HungryHungryHippo"
        commented="This is my go-to movie to binge, especially during lock down. Since
            shelter-in-place orders have gone into place, I've watched and
            re-watched La La Land four times. Nothing like a good musical to put
            you in a good mood and distract you from the rest of the world!"
      />
      <Comments
        src="https://upload.wikimedia.org/wikipedia/en/thumb/7/72/USC_Trojan_head.svg/220px-USC_Trojan_head.svg.png"
        alt="TrojanTommy profile"
        date="Posted: 02/13/2019"
        username="TrojanTommy"
        commented="Honestly, I'm not a huge fan of rom-coms, but this one was done so
            well I can't even resist it.The music score of this movie is really
            something special. I've been playing Mia and Sebastian's Theme on
            Spotify for the past week."
      />
      <Comments
        src="https://www.content.mycutegraphics.com/graphics/bear/brown-bear-standing.png"
        alt="Merbear profile"
        date="Posted: 06/19/2017"
        username="Merbear"
        commented="Maybe I'm biased because I'm no the biggest fan of Ryan Gosling, but
            I felt like this movie left something to be desired. I just don't
            understand the ending. What's the point of having Mia and Sebastian
            just imagine a life together? Why couldn't they just end up
            together? I don't know, this just felt like an unfinished movie to
            me. No satisfying ending!"
      />

      {/* <div className="comment">
        <img
          src="https://www.freeiconspng.com/uploads/person-icon-person-icon-clipart-image-from-our-icon-clipart-category--9.png"
          alt="Anonymous Commenter Profile Picture."
          className="anon-pfp"
        />
        <div className="comment-box">
          <p>Posted: 09/24/2023 by Hesterp</p>
          <p>
            Even after all these years, this is still my favorite movie by far.
            These roles were meant for Ryan Gosling and Emma Stone to play. I
            can't imagine a better cast or director.
          </p>
        </div>
      </div>

      <div className="comment">
        <img
          src="https://www.freeiconspng.com/uploads/person-icon-person-icon-clipart-image-from-our-icon-clipart-category--9.png"
          alt="Anonymous Commenter Profile Picture."
          className="anon-pfp"
        />
        <div className="comment-box">
          <p>Posted: 07/16/2020 by HungryHungryHippo</p>
          <p>
            This is my go-to movie to binge, especially during lock down. Since
            shelter-in-place orders have gone into place, I've watched and
            re-watched La La Land four times. Nothing like a good musical to put
            you in a good mood and distract you from the rest of the world!
          </p>
        </div>
      </div>

      <div className="comment">
        <img
          src="https://www.freeiconspng.com/uploads/person-icon-person-icon-clipart-image-from-our-icon-clipart-category--9.png"
          alt="Anonymous Commenter Profile Picture."
          className="anon-pfp"
        />
        <div className="comment-box">
          <p>Posted: 02/13/2019 by TrojanTommy</p>
          <p>
            Honestly, I'm not a huge fan of rom-coms, but this one was done so
            well I can't even resist it.The music score of this movie is really
            something special. I've been playing Mia and Sebastian's Theme on
            Spotify for the past week.
          </p>
        </div>
      </div>

      <div className="comment">
        <img
          src="https://www.freeiconspng.com/uploads/person-icon-person-icon-clipart-image-from-our-icon-clipart-category--9.png"
          alt="Anonymous Commenter Profile Picture."
          className="anon-pfp"
        />
        <div className="comment-box">
          <p>Posted: 06/19/2017 by Merbear</p>
          <p>
            Maybe I'm biased because I'm no the biggest fan of Ryan Gosling, but
            I felt like this movie left something to be desired. I just don't
            understand the ending. What's the point of having Mia and Sebastian
            just imagine a life together? Why couldn't they just end up
            together? I don't know, this just felt like an unfinished movie to
            me. No satisfying ending!
          </p>
        </div>
      </div> */}
    </div>
  </React.StrictMode>
);
