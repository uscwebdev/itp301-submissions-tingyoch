import React from 'react';

export default function Comments(props) {
  return (
    <div className="comment">
      <img src={props.src} alt={props.alt} className="anon-pfp" />
      <div className="comment-box">
        <p>{props.date}</p>
        <p>{props.username}</p>
        <p>{props.commented}</p>
      </div>
    </div>
  );
}
