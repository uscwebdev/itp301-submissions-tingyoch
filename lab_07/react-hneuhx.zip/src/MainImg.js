import React from 'react';
import { useState } from 'react';

export default function MainImg() {
  //initialize useState
  const [src, setSrc] = useState(
    'https://cdn.philz.us/products/6258556ae5a8c.png'
  );

  const [alt, setAlt] = useState('Honey Haze');

  const [caption, setCaption] = useState('Honey Haze');

  function handleImageChange(newSrc, newAlt, newCaption) {
    setSrc(newSrc);
    setAlt(newAlt);
    setCaption(newCaption);
  }

  return (
    <div id="content">
      <div id="heading">
        <h1>Philz Coffee Recommendations</h1>
      </div>

      <div id="nav">
        <button
          className="nav-button"
          onClick={() => {
            handleImageChange(
              'https://cdn.philz.us/products/6258556ae5a8c.png',
              'Honey Haze',
              'Honey Haze'
            );
          }}
        >
          Honey Haze
        </button>
        <button
          className="nav-button"
          onClick={() => {
            handleImageChange(
              'https://cdn.philz.us/products/IcedCoffee_MintMojito_Cream.png',
              'Mint Mojito',
              'Mint Mojito'
            );
          }}
        >
          Mint Mojito
        </button>
        <button
          className="nav-button"
          onClick={() => {
            handleImageChange(
              'https://cdn.philz.us/products/IcedCoffee_Rose.png',
              'Iced Coffee Rose',
              'Iced Coffee Rose'
            );
          }}
        >
          Iced Coffee Rose
        </button>
        <button
          className="nav-button"
          onClick={() => {
            handleImageChange(
              'https://cdn.philz.us/products/HotCoffee_Black.png',
              'Philtered Soul',
              'Philtered Soul'
            );
          }}
        >
          Philtered Soul
        </button>
        <button
          className="nav-button"
          onClick={() => {
            handleImageChange(
              'https://cdn.philz.us/products/HotCoffee_Soy.png',
              'New Manhattan',
              'New Manhattan'
            );
          }}
        >
          New Manhattan
        </button>
      </div>

      <div id="main-container">
        <img src={src} alt={alt} />
        <h3>{caption}</h3>
      </div>
    </div>
  );
}
