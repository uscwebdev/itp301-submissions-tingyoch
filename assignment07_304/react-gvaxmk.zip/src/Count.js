import React from 'react';
import { useState } from 'react';

export default function Count() {
  const [count, setCount] = useState(0);

  function handleIncrementAdd() {
    console.log(count);
    setCount(count + 1);
    console.log(count);
  }

  function handleIncrementSub() {
    console.log(count);
    if (count > 0) {
      setCount(count - 1);
      console.log(count);
    }
  }

  return (
    <div className="counter">
      <button className="text" onClick={handleIncrementSub}>
        -
      </button>
      <h3>{count}</h3>
      <button className="text" onClick={handleIncrementAdd}>
        +
      </button>
    </div>
  );
}
