import React from 'react';
import { useState } from 'react';
import './index.css';

export default function Puffles() {
  const [subtotal, setSubtotal] = useState(0);
  function handleSubtotalAdd(price) {
    setSubtotal(subtotal + parseInt(price));
    console.log(subtotal);
  }

  function handleSubtotalSub(price) {
    if (subtotal > 0) {
      setSubtotal(subtotal - parseInt(price));
      console.log(setSubtotal);
    }
  }

  return (
    <div>
      <div id="puffle-section">
        <Puffle
          src="https://i.pinimg.com/736x/45/70/53/457053101190bd6df521c06d5b6dd699.jpg"
          color="Blue"
          price="15"
          EventAdd={handleSubtotalAdd}
          EventSub={handleSubtotalSub}
        />

        <Puffle
          src="https://i.pinimg.com/236x/4f/7a/b3/4f7ab33f0928af2c08cbf411d1cc2699--club-penguin-pet-store.jpg"
          color="Pink"
          price="30"
          EventAdd={handleSubtotalAdd}
          EventSub={handleSubtotalSub}
        />

        <Puffle
          src="https://pm1.aminoapps.com/6322/3f8664c0deb10e4a6c0cf16882ff5e497f25e6b4_00.jpg"
          color="Yellow"
          price="20"
          EventAdd={handleSubtotalAdd}
          EventSub={handleSubtotalSub}
        />

        <Puffle
          src="https://i.pinimg.com/1200x/ca/36/f1/ca36f138ac5b11fa7c5106bcd387fa76.jpg"
          color="Green"
          price="13"
          EventAdd={handleSubtotalAdd}
          EventSub={handleSubtotalSub}
        />

        <Puffle
          src="https://i.pinimg.com/originals/13/50/7a/13507a4321f2f6bf7bf998d4855f877b.jpg"
          color="Purple"
          price="23"
          EventAdd={handleSubtotalAdd}
          EventSub={handleSubtotalSub}
        />

        <Puffle
          src="https://pm1.aminoapps.com/6433/4be6b9f5ba026e5a08fed55e7d5d88092deee8f6_00.jpg"
          color="Rainbow"
          price="65"
          EventAdd={handleSubtotalAdd}
          EventSub={handleSubtotalSub}
        />
      </div>
      <div id="subtotal">
        <h2>Subtotal: ${subtotal}</h2>
      </div>
    </div>
  );
}

function Puffle(props) {
  const [count, setCount] = useState(0);

  function handleIncrementAdd() {
    console.log(count);
    setCount(count + 1);
    console.log(count);
    props.EventAdd(props.price);
  }

  function handleIncrementSub() {
    console.log(count);
    if (count > 0) {
      setCount(count - 1);
      console.log(count);
      props.EventSub(props.price);
    }
  }

  return (
    <div className="puffle">
      <div className="puffle-image">
        <img
          src={props.src}
          alt={props.color + 'Puffle'}
          className="pic-size"
        />
      </div>
      <div className="puffle-details">
        <h3>{props.color + ' Puffle'}</h3>
        <h3>${props.price}</h3>

        <div className="counter">
          <button className="text" id="sub-btn" onClick={handleIncrementSub}>
            -
          </button>
          <h3>{count}</h3>
          <button className="text" id="add-btn" onClick={handleIncrementAdd}>
            +
          </button>
        </div>
      </div>
    </div>
  );
}
