import React from 'react';
import { createRoot } from 'react-dom/client';
import Puffles from './Puffle.js';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div id="heading-title">
      <h1>Puffles FLASH SALE</h1>
    </div>

    <div id="full-content-box">
      <Puffles />
    </div>

    <div id="footer">
      <h4>Puffle Inc.</h4>
    </div>
  </React.StrictMode>
);
