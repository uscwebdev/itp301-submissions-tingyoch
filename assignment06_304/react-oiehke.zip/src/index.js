import React from 'react';
import { createRoot } from 'react-dom/client';
import Puffle from './Puffle.js';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div id="heading-title">
      <h1>Puffles FLASH SALE</h1>
    </div>

    <div id="content-box">
      <div id="puffles">
        <Puffle
          src="https://i.pinimg.com/736x/45/70/53/457053101190bd6df521c06d5b6dd699.jpg"
          color="Blue"
          price="$15"
        />

        <Puffle
          src="https://i.pinimg.com/236x/4f/7a/b3/4f7ab33f0928af2c08cbf411d1cc2699--club-penguin-pet-store.jpg"
          color="Pink"
          price="$30"
        />

        <Puffle
          src="https://pm1.aminoapps.com/6322/3f8664c0deb10e4a6c0cf16882ff5e497f25e6b4_00.jpg"
          color="Yellow"
          price="$20"
        />

        <Puffle
          src="https://i.pinimg.com/1200x/ca/36/f1/ca36f138ac5b11fa7c5106bcd387fa76.jpg"
          color="Green"
          price="$13"
        />

        <Puffle
          src="https://i.pinimg.com/originals/13/50/7a/13507a4321f2f6bf7bf998d4855f877b.jpg"
          color="Purple"
          price="$23"
        />

        <Puffle
          src="https://pm1.aminoapps.com/6433/4be6b9f5ba026e5a08fed55e7d5d88092deee8f6_00.jpg"
          color="Rainbow"
          price="$65"
        />
      </div>
    </div>

    <div id="footer">
      <h4>Puffle Inc.</h4>
    </div>
  </React.StrictMode>
);
