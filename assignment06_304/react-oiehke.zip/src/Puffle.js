import React from 'react';
import './index.css';

export default function Puffle(props) {
  return (
    <div className="puffle">
      <div className="puffle-image">
        <img
          src={props.src}
          alt={props.color + 'Puffle'}
          className="pic-size"
        />
      </div>
      <div className="puffle-details">
        <h3>{props.color + ' Puffle'}</h3>
        <h3>{props.price}</h3>
      </div>
    </div>
  );
}
